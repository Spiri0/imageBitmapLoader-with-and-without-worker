export const FS = `

	varying vec2 vUv;
	uniform sampler2D tex;


	void main() {

		vec3 diffuse = texture(tex, vUv).rgb;

		gl_FragColor = vec4(diffuse, 1.);
		//gl_FragColor = vec4(1., 0., 0., 1.);

	}
`;