import {main} from "./main.js";
new main.Main();
