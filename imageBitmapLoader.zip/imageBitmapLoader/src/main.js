import * as THREE from "../libs/three/build/three.module.js";
import {VS} from "../shader/VS.js";
import {FS} from "../shader/FS.js";


export const main = (() => {

class Main{
	constructor(){

		this.worker = new Worker('./src/worker.js', {type: 'module'});
	
		this.init();
		this.animate();
	
		this.worker.onmessage = (e) => {		
			const texture = new THREE.CanvasTexture(e.data);
			this.material.uniforms.tex.value = texture;
			this.material.uniformsNeedUpdate = true;			
		};
	
	}//end constructor


	init(){
		this.renderer = new THREE.WebGLRenderer( { antialias: true } );
		this.renderer.setPixelRatio( window.devicePixelRatio ); 
		this.renderer.shadowMap.enabled = true; 
		this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
		this.renderer.autoClear = false;
		
		this.container = document.getElementById('container');
		this.renderer.setSize(this.container.clientWidth, this.container.clientHeight);
		this.container.appendChild( this.renderer.domElement );

		this.aspect = this.container.clientWidth / this.container.clientHeight; 
		this.scene = new THREE.Scene();
		this.scene.background = new THREE.Color( 0x000000 );
		//this.renderer.setClearColor( 0x000000 );
		
		this.camera = new THREE.PerspectiveCamera( 50, this.aspect, 0.1, 1000000 );
		this.camera.position.set(0, 0, 400);
		
		
		this.newTex = 0;
	
		
		let uniform = {
			tex: {value: new THREE.TextureLoader().load( './textures/waternormals.jpg' )},
		}


     this.material = new THREE.ShaderMaterial({
     	uniforms: uniform,
     	vertexShader: VS,
     	fragmentShader: FS,
		});
	
		
		const geometry = new THREE.BoxGeometry( 100, 100, 100 ); 
		const cube = new THREE.Mesh( geometry, this.material ); 
		this.scene.add( cube );
		
		
	}//end init


	animate(){
		requestAnimationFrame( this.animate.bind(this) );  
		this.render();
	}
	
	render(){
	
		if(this.newTex == 0){
//			this.NewTexLoader();		//main thread version
			this.postMessage();		//worker thread version
			this.newTex = 1;
		}
		
		this.camera.updateProjectionMatrix();	
		this.renderer.render(this.scene, this.camera); 
	}
	
	
	NewTexLoader(){
		const loader = new THREE.ImageBitmapLoader()
		.load('./textures/lenna.png', function (image){
			const texture = new THREE.CanvasTexture(image);
			this.material.uniforms.tex.value = texture;
			this.material.uniformsNeedUpdate = true;
		 });	 
	}


	postMessage(msg){
		this.worker.postMessage(msg);
	}	
	
}//end class


return {
	Main
};
})();



	