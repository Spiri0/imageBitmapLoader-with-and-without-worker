import * as THREE from "../libs/three/build/three.module.js";




self.onmessage = async (msg) => {

	const loader = new THREE.ImageBitmapLoader();
	const image = await loader.loadAsync('../textures/lenna.png');

	self.postMessage(image);
 
};